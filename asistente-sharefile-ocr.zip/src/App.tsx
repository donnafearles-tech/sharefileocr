import React, { useState, useEffect, useRef } from "react";
import {
  Search,
  Folder,
  FileText,
  Download,
  ScanFace,
  Phone,
  CheckCircle2,
  AlertCircle,
  Play,
  RotateCcw,
  Upload,
  Plus,
  Trash2,
  Edit3,
  Terminal,
  ArrowRight,
  Sparkles,
  Cpu,
  FileImage,
  Check,
  ChevronRight,
  Info,
  HelpCircle,
  Clock,
  ExternalLink,
  Copy,
  Layers
} from "lucide-react";
import {
  ShareFileFolder,
  ShareFileFile,
  ExecutionLog,
  AssistantConfig,
  AssistantResult,
  StepId,
  StepState
} from "./types";

export default function App() {
  // System Config States
  const [config, setConfig] = useState<AssistantConfig>({
    folderName: "Cuentas VIP",
    fileNameContains: "VIP",
    useRealAI: true // Controlled by backend presence of key but togglable
  });

  // ShareFile State
  const [folders, setFolders] = useState<ShareFileFolder[]>([]);
  const [files, setFiles] = useState<ShareFileFile[]>([]);
  const [selectedFileForOcr, setSelectedFileForOcr] = useState<ShareFileFile | null>(null);

  // Assistant Execution States
  const [isRunning, setIsRunning] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(-1);
  const [executionLogs, setExecutionLogs] = useState<ExecutionLog[]>([]);
  const [finalResult, setFinalResult] = useState<AssistantResult | null>(null);
  const [apiResult, setApiResult] = useState<any | null>(null);
  const [executionSpeed, setExecutionSpeed] = useState<"fast" | "normal" | "step">("normal");

  // Handwriting Canvas & Upload Creator States
  const [customNoteText, setCustomNoteText] = useState("");
  const [customNotePhone, setCustomNotePhone] = useState("(305) 555-0143");
  const [customFileName, setCustomFileName] = useState("VIP_Client_Note.png");
  const [customFolderId, setCustomFolderId] = useState("folder-vip");
  const [creationMode, setCreationMode] = useState<"text" | "draw">("text");
  const [isCreatingNewFile, setIsCreatingNewFile] = useState(false);

  // Drawing Canvas Ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  // Step state tracker for visual UI
  const [steps, setSteps] = useState<StepState[]>([
    {
      id: "SEARCH_FOLDERS",
      label: "Buscar Carpeta",
      description: "Localiza la carpeta de destino en ShareFile usando búsqueda parcial.",
      status: "idle"
    },
    {
      id: "LIST_ITEMS",
      label: "Listar Archivos",
      description: "Obtiene la lista completa de documentos y archivos dentro de la carpeta.",
      status: "idle"
    },
    {
      id: "IDENTIFY_FILE",
      label: "Identificar Documento",
      description: "Filtra la lista por palabra clave (ej. 'VIP') para identificar el archivo correcto.",
      status: "idle"
    },
    {
      id: "DOWNLOAD_FILE",
      label: "Descargar Archivo",
      description: "Descarga de forma segura el archivo de imagen de ShareFile en memoria.",
      status: "idle"
    },
    {
      id: "EXTRACT_TEXT",
      label: "OCR Inteligente (Gemini)",
      description: "Procesa la imagen para extraer texto manuscrito y digital.",
      status: "idle"
    },
    {
      id: "FIND_PHONE",
      label: "Extraer Teléfono",
      description: "Analiza el texto mediante patrones y expresiones regulares para aislar el número.",
      status: "idle"
    },
    {
      id: "RETURN_RESULT",
      label: "Devolver Resultado",
      description: "Estructura la información en una respuesta JSON estandarizada.",
      status: "idle"
    }
  ]);

  // Loading indicator for list updates
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [copied, setCopied] = useState(false);
  const [notification, setNotification] = useState<{ message: string; type: "success" | "info" | "error" } | null>(null);

  // Auto-scroll logs ref
  const logsEndRef = useRef<HTMLDivElement | null>(null);

  // Initialize folders and files on mount
  useEffect(() => {
    fetchFolders();
  }, []);

  useEffect(() => {
    if (folders.length > 0) {
      initializeDefaultFiles();
    }
  }, [folders]);

  // Handle logs auto-scrolling
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [executionLogs]);

  // Trigger temporary notification helper
  const showNotification = (message: string, type: "success" | "info" | "error" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  const fetchFolders = async () => {
    try {
      const res = await fetch("/api/sharefile/folders");
      const data = await res.json();
      setFolders(data);
    } catch (err) {
      console.error("Error al obtener carpetas:", err);
    }
  };

  const fetchFiles = async () => {
    setIsLoadingFiles(true);
    try {
      // Fetch files for each folder and merge them
      const allFiles: ShareFileFile[] = [];
      for (const folder of folders) {
        const res = await fetch(`/api/sharefile/list-items?folderId=${folder.id}`);
        const data = await res.json();
        if (data.files) {
          // Re-attach data from simulator if possible or just map
          data.files.forEach((f: any) => {
            allFiles.push({
              ...f,
              base64Data: "", // server holds actual base64, we pull it on download
              text: ""
            });
          });
        }
      }
      setFiles(allFiles);
    } catch (err) {
      console.error("Error al listar archivos:", err);
    } finally {
      setIsLoadingFiles(false);
    }
  };

  // Generate baseline handwritten note on a virtual canvas
  const generateHandwrittenImage = (text: string, titleText: string = "NOTA VIP"): { base64: string, estimatedSize: number } => {
    const canvas = document.createElement("canvas");
    canvas.width = 600;
    canvas.height = 400;
    const ctx = canvas.getContext("2d");
    if (!ctx) return { base64: "", estimatedSize: 0 };

    // Draw notepad paper background
    ctx.fillStyle = "#FCFCF9"; // soft notebook cream color
    ctx.fillRect(0, 0, 600, 400);

    // Draw notebook lines
    ctx.strokeStyle = "#E2E8F0";
    ctx.lineWidth = 1;
    for (let y = 50; y < 400; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(600, y);
      ctx.stroke();
    }

    // Draw notebook red margin line
    ctx.strokeStyle = "#FCA5A5";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(60, 0);
    ctx.lineTo(60, 400);
    ctx.stroke();

    // Draw coffee cup stain or a little aesthetic element (top right)
    ctx.fillStyle = "rgba(180, 140, 100, 0.05)";
    ctx.beginPath();
    ctx.arc(500, 80, 40, 0, Math.PI * 2);
    ctx.fill();

    // Draw header/title text
    ctx.font = "bold 20px 'Architects Daughter', cursive, 'Comic Sans MS', sans-serif";
    ctx.fillStyle = "#1E3A8A"; // deep ink blue
    ctx.fillText(titleText, 80, 40);

    // Write handwritten lines
    ctx.font = "18px 'Architects Daughter', cursive, 'Comic Sans MS', sans-serif";
    ctx.fillStyle = "#1E293B"; // graphite color

    const lines = text.split("\n");
    let startY = 82;
    lines.forEach((line) => {
      // Add slight random horizontal offset to make it look authentic
      const randomX = Math.random() * 3 - 1.5;
      ctx.fillText(line, 80 + randomX, startY);
      startY += 30; // matches line height
    });

    const base64 = canvas.toDataURL("image/png");
    // estimate size based on length of base64
    const estimatedSize = Math.round(base64.length * 0.75);

    return { base64, estimatedSize };
  };

  const initializeDefaultFiles = async () => {
    try {
      // Create beautiful default simulated images
      const sample1Text = "VIP Contact Info:\nClient: John Smith\nUrgent callback requested regarding account setup.\nTel: (305) 555-0143\nBest times: 9am - 5pm EST.\nAtentamente, Admin.";
      const sample1 = generateHandwrittenImage(sample1Text, "CONTACTO VIP - URGENTE");

      const sample2Text = "CLIENTE VIP - SEGUIMIENTO COMPRA\nNombre: María Gómez\nTeléfono de contacto directo: 415-555-8721\nPor favor llamar mañana sin falta.\nUn saludo.";
      const sample2 = generateHandwrittenImage(sample2Text, "REPORTE DE VENTAS VIP");

      const sample3Text = "VIP Partner Hotline:\nCall us at 212-555-0988 for support.\nAll services active.";
      const sample3 = generateHandwrittenImage(sample3Text, "SOPORTE DE SOCIOS VIP");

      const sample4Text = "Factura comercial normal.\nTotal a pagar: $250.00.\nNo requiere atencion especial.";
      const sample4 = generateHandwrittenImage(sample4Text, "FACTURA DE CLIENTE REGULAR");

      const initialFiles = [
        {
          id: "file-vip-john",
          name: "VIP_Contact_Note_John_Smith.png",
          folderId: "folder-vip",
          mimeType: "image/png",
          size: sample1.estimatedSize,
          createdAt: new Date("2026-06-25T14:30:00").toISOString(),
          base64Data: sample1.base64,
          text: sample1Text
        },
        {
          id: "file-vip-maria",
          name: "VIP_Sales_Maria_Gomez.png",
          folderId: "folder-vip",
          mimeType: "image/png",
          size: sample2.estimatedSize,
          createdAt: new Date("2026-06-26T10:15:00").toISOString(),
          base64Data: sample2.base64,
          text: sample2Text
        },
        {
          id: "file-vip-partner",
          name: "VIP_Partner_Hotline.png",
          folderId: "folder-leads",
          mimeType: "image/png",
          size: sample3.estimatedSize,
          createdAt: new Date("2026-06-26T16:45:00").toISOString(),
          base64Data: sample3.base64,
          text: sample3Text
        },
        {
          id: "file-invoice-regular",
          name: "Regular_Invoice_Standard.png",
          folderId: "folder-regular",
          mimeType: "image/png",
          size: sample4.estimatedSize,
          createdAt: new Date("2026-06-24T09:00:00").toISOString(),
          base64Data: sample4.base64,
          text: sample4Text
        }
      ];

      // POST to /api/sharefile/initialize
      await fetch("/api/sharefile/initialize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ initialFiles })
      });

      fetchFiles();
    } catch (err) {
      console.error("Error al inicializar archivos predeterminados:", err);
    }
  };

  // Canvas drawing functions
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.strokeStyle = "#1E3A8A"; // blue ink
    ctx.lineWidth = 3.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#FCFCF9";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw notebook lines again
    ctx.strokeStyle = "#E2E8F0";
    ctx.lineWidth = 1;
    for (let y = 40; y < canvas.height; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }
  };

  // Setup Canvas when drawing mode turns on
  useEffect(() => {
    if (creationMode === "draw" && canvasRef.current) {
      clearCanvas();
    }
  }, [creationMode, isCreatingNewFile]);

  // Handle upload of custom created file
  const handleUploadCustomFile = async () => {
    let finalBase64 = "";
    let finalRawText = "";

    if (creationMode === "text") {
      if (!customNoteText.trim()) {
        showNotification("Por favor ingresa el texto de la nota.", "error");
        return;
      }
      const phoneString = customNotePhone.trim();
      const content = `${customNoteText}\n${phoneString ? `Tel: ${phoneString}` : ""}`;
      const imgObj = generateHandwrittenImage(content, "NOTA MANUAL");
      finalBase64 = imgObj.base64;
      finalRawText = content;
    } else {
      // canvas draw mode
      const canvas = canvasRef.current;
      if (!canvas) return;
      finalBase64 = canvas.toDataURL("image/png");
      finalRawText = `[Imagen manuscrita dibujada a mano] Contiene el teléfono: ${customNotePhone}`;
    }

    if (!customFileName.trim()) {
      showNotification("Por favor especifica un nombre para el archivo.", "error");
      return;
    }

    try {
      const res = await fetch("/api/sharefile/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: customFileName.endsWith(".png") ? customFileName : `${customFileName}.png`,
          folderId: customFolderId,
          base64Data: finalBase64,
          text: finalRawText,
          mimeType: "image/png"
        })
      });

      const data = await res.json();
      if (data.success) {
        showNotification(`¡Archivo "${data.file.name}" cargado en ShareFile con éxito!`);
        setIsCreatingNewFile(false);
        setCustomNoteText("");
        // Refresh files list
        fetchFiles();
      } else {
        showNotification("Ocurrió un error al cargar el archivo.", "error");
      }
    } catch (err: any) {
      showNotification(`Error: ${err.message}`, "error");
    }
  };

  const handleResetDatabase = async () => {
    if (confirm("¿Estás seguro de que deseas restablecer ShareFile a los archivos predeterminados?")) {
      try {
        await fetch("/api/sharefile/reset", { method: "POST" });
        await initializeDefaultFiles();
        showNotification("Se restableció la base de datos de ShareFile.");
        // Clear active assistant execution state
        handleResetAssistant();
      } catch (err: any) {
        showNotification(`Error al restablecer: ${err.message}`, "error");
      }
    }
  };

  const handleResetAssistant = () => {
    setIsRunning(false);
    setCurrentStepIndex(-1);
    setExecutionLogs([]);
    setFinalResult(null);
    setApiResult(null);
    setSelectedFileForOcr(null);
    setSteps(prev => prev.map(s => ({ ...s, status: "idle", result: undefined })));
  };

  // Helper delay function
  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  // Run the entire assistant orchestrator from the client
  // Supports Step-by-Step, Fast, and Normal speeds
  const runAssistant = async () => {
    if (isRunning) return;
    
    // Reset states
    setIsRunning(true);
    setFinalResult(null);
    setApiResult(null);
    setSelectedFileForOcr(null);
    setExecutionLogs([]);
    
    const logs: ExecutionLog[] = [];
    const addLog = (level: "info" | "success" | "warning" | "error", message: string, payload?: any) => {
      const newLog = { timestamp: new Date().toLocaleTimeString(), level, message, payload };
      logs.push(newLog);
      setExecutionLogs([...logs]);
    };

    // Initialize all steps to idle/running
    setSteps(prev => prev.map(s => ({ ...s, status: "idle" })));

    const getDelayMs = () => {
      if (executionSpeed === "fast") return 300;
      return 1500; // normal speed
    };

    try {
      // Step 1: SEARCH_FOLDERS
      setCurrentStepIndex(0);
      setSteps(prev => prev.map((s, idx) => idx === 0 ? { ...s, status: "running" } : s));
      addLog("info", `[Paso 1/7] Buscando la carpeta "${config.folderName || 'Carpeta Raíz'}" en ShareFile...`);
      await delay(getDelayMs());

      let matchedFolder: ShareFileFolder | null = null;
      if (!config.folderName.trim()) {
        matchedFolder = folders.find(f => f.id === "root") || null;
        addLog("success", `No se especificó carpeta. Usando la Carpeta Raíz por defecto (ID: ${matchedFolder?.id})`);
      } else {
        const query = config.folderName.trim().toLowerCase();
        const matches = folders.filter(f => f.name.toLowerCase().includes(query));
        if (matches.length === 0) {
          addLog("warning", `No se encontró coincidencia para "${config.folderName}". Usando Carpeta Raíz.`);
          matchedFolder = folders.find(f => f.id === "root") || null;
        } else {
          matchedFolder = matches[0];
          addLog("success", `Carpeta localizada con éxito: "${matchedFolder.name}" (ID: ${matchedFolder.id})`);
        }
      }

      if (!matchedFolder) {
        throw new Error("No se pudo resolver ninguna carpeta en ShareFile.");
      }

      setSteps(prev => prev.map((s, idx) => idx === 0 ? { ...s, status: "success", result: matchedFolder } : s));

      // Step 2: LIST_ITEMS
      setCurrentStepIndex(1);
      setSteps(prev => prev.map((s, idx) => idx === 1 ? { ...s, status: "running" } : s));
      addLog("info", `[Paso 2/7] Listando archivos en la carpeta: "${matchedFolder.name}" (ID: ${matchedFolder.id})`);
      await delay(getDelayMs());

      // Fetch files from server
      const listRes = await fetch(`/api/sharefile/list-items?folderId=${matchedFolder.id}`);
      const listData = await listRes.json();
      const folderFiles: ShareFileFile[] = listData.files || [];
      addLog("success", `Se encontraron ${folderFiles.length} archivos en el directorio de ShareFile.`, folderFiles);
      setSteps(prev => prev.map((s, idx) => idx === 1 ? { ...s, status: "success", result: folderFiles } : s));

      // Step 3: IDENTIFY_FILE
      setCurrentStepIndex(2);
      setSteps(prev => prev.map((s, idx) => idx === 2 ? { ...s, status: "running" } : s));
      addLog("info", `[Paso 3/7] Filtrando por nombre de archivo contenga "${config.fileNameContains}" (insensible a mayúsculas/minúsculas)...`);
      await delay(getDelayMs());

      const searchTerm = config.fileNameContains.trim().toLowerCase();
      const matchedFiles = folderFiles.filter(f => f.name.toLowerCase().includes(searchTerm));

      if (matchedFiles.length === 0) {
        addLog("error", `No se encontró ningún archivo con el patrón "${config.fileNameContains}" en la carpeta "${matchedFolder.name}".`);
        setSteps(prev => prev.map((s, idx) => idx === 2 ? { ...s, status: "error" } : s));
        
        const finalErrResult: AssistantResult = {
          status: "error",
          phone_number: null,
          message: `No se encontró ningún archivo que contenga "${config.fileNameContains}" en la carpeta "${matchedFolder.name}".`
        };
        setFinalResult(finalErrResult);
        setApiResult({
          status: "error",
          phone_number: null,
          message: finalErrResult.message,
          logs: logs.map(l => l.message)
        });
        setIsRunning(false);
        return;
      }

      // Choose first or most recent (we'll pick the first matching file)
      const targetFileSummary = matchedFiles[0];
      addLog("success", `Archivo VIP identificado: "${targetFileSummary.name}" (ID: ${targetFileSummary.id})`);
      setSteps(prev => prev.map((s, idx) => idx === 2 ? { ...s, status: "success", result: targetFileSummary } : s));

      // Step 4: DOWNLOAD_FILE
      setCurrentStepIndex(3);
      setSteps(prev => prev.map((s, idx) => idx === 3 ? { ...s, status: "running" } : s));
      addLog("info", `[Paso 4/7] Descargando contenido binario completo de "${targetFileSummary.name}"...`);
      await delay(getDelayMs());

      const downloadRes = await fetch(`/api/sharefile/download-file?fileId=${targetFileSummary.id}`);
      const downloadData = await downloadRes.json();
      const downloadedFile: ShareFileFile = downloadData.file;

      // Set target file state for rendering visual note
      setSelectedFileForOcr(downloadedFile);

      addLog("success", `¡Descarga de ShareFile completa! Archivo cargado en buffer temporal. Tamaño: ${downloadedFile.size} bytes. Tipo: ${downloadedFile.mimeType}`);
      setSteps(prev => prev.map((s, idx) => idx === 3 ? { ...s, status: "success", result: downloadedFile } : s));

      // Step 5: EXTRACT_TEXT
      setCurrentStepIndex(4);
      setSteps(prev => prev.map((s, idx) => idx === 4 ? { ...s, status: "running" } : s));
      addLog("info", `[Paso 5/7] Procesando OCR. Extrayendo escritura a mano de "${downloadedFile.name}"...`);
      await delay(getDelayMs());

      const ocrRes = await fetch("/api/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          base64Data: downloadedFile.base64Data,
          mimeType: downloadedFile.mimeType,
          groundTruthText: downloadedFile.text
        })
      });
      const ocrData = await ocrRes.json();
      const extractedText = ocrData.text || "";

      addLog("success", `OCR completado. Motor: ${ocrData.isSimulated ? "Simulador heurístico local" : "Inteligencia Artificial Gemini 3.5 Flash"}`);
      addLog("info", `Texto extraído:\n"${extractedText}"`);
      setSteps(prev => prev.map((s, idx) => idx === 4 ? { ...s, status: "success", result: extractedText } : s));

      // Step 6: FIND_PHONE
      setCurrentStepIndex(5);
      setSteps(prev => prev.map((s, idx) => idx === 5 ? { ...s, status: "running" } : s));
      addLog("info", `[Paso 6/7] Ejecutando análisis heurístico y expresiones regulares en el texto extraído...`);
      await delay(getDelayMs());

      // Regex matches common US and international phone patterns
      const phoneRegex = /(?:\+?(\d{1,3})[-. ]*)?\(?(\d{3})\)?[-. ]*(\d{3})[-. ]*(\d{4})/g;
      const matchesPhone = [...extractedText.matchAll(phoneRegex)];
      
      let phoneNumber: string | null = null;
      if (matchesPhone && matchesPhone.length > 0) {
        phoneNumber = matchesPhone[0][0];
        addLog("success", `¡Teléfono detectado en el manuscrito!: ${phoneNumber}`);
      } else {
        // Fallback generic search
        const genericPhoneRegex = /\b\d{3}[-.\s]?\d{3,4}[-.\s]?\d{4}\b/g;
        const secondMatch = extractedText.match(genericPhoneRegex);
        if (secondMatch && secondMatch.length > 0) {
          phoneNumber = secondMatch[0];
          addLog("success", `¡Teléfono detectado en formato secundario!: ${phoneNumber}`);
        } else {
          addLog("warning", "No se detectó ningún número de teléfono estándar en la nota manuscrita.");
        }
      }

      setSteps(prev => prev.map((s, idx) => idx === 5 ? { ...s, status: "success", result: phoneNumber } : s));

      // Step 7: RETURN_RESULT
      setCurrentStepIndex(6);
      setSteps(prev => prev.map((s, idx) => idx === 6 ? { ...s, status: "running" } : s));
      addLog("info", `[Paso 7/7] Compilando objeto de salida JSON según el formato especificado...`);
      await delay(getDelayMs());

      const apiResponsePayload = {
        status: phoneNumber ? "success" : "error",
        phone_number: phoneNumber,
        message: phoneNumber
          ? `El número de teléfono fue extraído exitosamente de la imagen manuscrita de ShareFile.`
          : "No se encontró ningún número de teléfono en la imagen.",
        metadata: {
          file_id: downloadedFile.id,
          file_name: downloadedFile.name,
          folder_name: matchedFolder.name,
          ocr_engine: ocrData.isSimulated ? "local-simulation-v1" : "gemini-3.5-flash",
          timestamp: new Date().toISOString()
        }
      };

      setFinalResult({
        status: phoneNumber ? "success" : "error",
        phone_number: phoneNumber,
        message: apiResponsePayload.message
      });
      setApiResult(apiResponsePayload);

      addLog("success", `¡Automatización completada con éxito!`);
      setSteps(prev => prev.map((s, idx) => idx === 6 ? { ...s, status: "success", result: apiResponsePayload } : s));
      setIsRunning(false);
      showNotification("¡Asistente completado de forma exitosa!");

    } catch (error: any) {
      addLog("error", `Error crítico en ejecución: ${error.message}`);
      setSteps(prev => {
        const updated = [...prev];
        if (currentStepIndex >= 0 && currentStepIndex < updated.length) {
          updated[currentStepIndex].status = "error";
        }
        return updated;
      });
      setFinalResult({
        status: "error",
        phone_number: null,
        message: `Error durante la automatización: ${error.message}`
      });
      setIsRunning(false);
    }
  };

  // Run the step-by-step debugger
  const handleNextStepDebug = async () => {
    // If not running, start step by step
    if (!isRunning) {
      setIsRunning(true);
      setCurrentStepIndex(0);
      setSteps(prev => prev.map((s, idx) => idx === 0 ? { ...s, status: "running" } : { ...s, status: "idle" }));
      setExecutionLogs([{
        timestamp: new Date().toLocaleTimeString(),
        level: "info",
        message: `Iniciando depurador de automatización paso a paso...`
      }]);
      return;
    }

    const nextIndex = currentStepIndex + 1;
    if (nextIndex >= steps.length) {
      setIsRunning(false);
      showNotification("Depuración finalizada.");
      return;
    }

    const addLog = (level: "info" | "success" | "warning" | "error", message: string, payload?: any) => {
      setExecutionLogs(prev => [...prev, {
        timestamp: new Date().toLocaleTimeString(),
        level,
        message,
        payload
      }]);
    };

    // Update steps status
    setSteps(prev => prev.map((s, idx) => {
      if (idx === currentStepIndex) return { ...s, status: "success" };
      if (idx === nextIndex) return { ...s, status: "running" };
      return s;
    }));
    setCurrentStepIndex(nextIndex);

    // Run actions based on nextIndex
    try {
      if (nextIndex === 1) { // LIST_ITEMS
        const matchedFolder = steps[0].result as ShareFileFolder;
        addLog("info", `[Paso 2/7] Listando archivos en la carpeta: "${matchedFolder.name}"`);
        const listRes = await fetch(`/api/sharefile/list-items?folderId=${matchedFolder.id}`);
        const listData = await listRes.json();
        const folderFiles = listData.files || [];
        addLog("success", `Se encontraron ${folderFiles.length} archivos en ShareFile.`, folderFiles);
        setSteps(prev => prev.map((s, idx) => idx === 1 ? { ...s, status: "success", result: folderFiles } : s));

      } else if (nextIndex === 2) { // IDENTIFY_FILE
        const folderFiles = steps[1].result as ShareFileFile[];
        addLog("info", `[Paso 3/7] Filtrando por nombre de archivo contenga "${config.fileNameContains}"...`);
        const searchTerm = config.fileNameContains.trim().toLowerCase();
        const matchedFiles = folderFiles.filter(f => f.name.toLowerCase().includes(searchTerm));

        if (matchedFiles.length === 0) {
          addLog("error", `No se encontró coincidencia en la carpeta.`);
          setSteps(prev => prev.map((s, idx) => idx === 2 ? { ...s, status: "error" } : s));
          setIsRunning(false);
          return;
        }
        const targetFileSummary = matchedFiles[0];
        addLog("success", `Identificado: "${targetFileSummary.name}"`);
        setSteps(prev => prev.map((s, idx) => idx === 2 ? { ...s, status: "success", result: targetFileSummary } : s));

      } else if (nextIndex === 3) { // DOWNLOAD_FILE
        const targetFileSummary = steps[2].result as ShareFileFile;
        addLog("info", `[Paso 4/7] Descargando contenido de "${targetFileSummary.name}"...`);
        const downloadRes = await fetch(`/api/sharefile/download-file?fileId=${targetFileSummary.id}`);
        const downloadData = await downloadRes.json();
        const downloadedFile = downloadData.file;
        setSelectedFileForOcr(downloadedFile);
        addLog("success", `Descarga completa de ShareFile. Tamaño: ${downloadedFile.size} bytes.`);
        setSteps(prev => prev.map((s, idx) => idx === 3 ? { ...s, status: "success", result: downloadedFile } : s));

      } else if (nextIndex === 4) { // EXTRACT_TEXT
        const downloadedFile = steps[3].result as ShareFileFile;
        addLog("info", `[Paso 5/7] Ejecutando OCR en manuscrito...`);
        const ocrRes = await fetch("/api/ocr", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            base64Data: downloadedFile.base64Data,
            mimeType: downloadedFile.mimeType,
            groundTruthText: downloadedFile.text
          })
        });
        const ocrData = await ocrRes.json();
        const extractedText = ocrData.text || "";
        addLog("success", `OCR Completado.`);
        addLog("info", `Texto extraído: "${extractedText}"`);
        setSteps(prev => prev.map((s, idx) => idx === 4 ? { ...s, status: "success", result: extractedText } : s));

      } else if (nextIndex === 5) { // FIND_PHONE
        const extractedText = steps[4].result as string;
        addLog("info", `[Paso 6/7] Analizando patrones de teléfono...`);
        const phoneRegex = /(?:\+?(\d{1,3})[-. ]*)?\(?(\d{3})\)?[-. ]*(\d{3})[-. ]*(\d{4})/g;
        const matchesPhone = [...extractedText.matchAll(phoneRegex)];
        let phoneNumber: string | null = null;
        if (matchesPhone && matchesPhone.length > 0) {
          phoneNumber = matchesPhone[0][0];
          addLog("success", `¡Teléfono localizado!: ${phoneNumber}`);
        } else {
          addLog("warning", "Teléfono no detectado con formato de 10 dígitos.");
        }
        setSteps(prev => prev.map((s, idx) => idx === 5 ? { ...s, status: "success", result: phoneNumber } : s));

      } else if (nextIndex === 6) { // RETURN_RESULT
        const phoneNumber = steps[5].result as string | null;
        const downloadedFile = steps[3].result as ShareFileFile;
        const matchedFolder = steps[0].result as ShareFileFolder;
        addLog("info", `[Paso 7/7] Generando salida JSON formateada...`);
        
        const apiResponsePayload = {
          status: phoneNumber ? "success" : "error",
          phone_number: phoneNumber,
          message: phoneNumber
            ? "El número de teléfono fue extraído exitosamente de la imagen manuscrita de ShareFile."
            : "No se encontró ningún número de teléfono en la imagen.",
          metadata: {
            file_id: downloadedFile.id,
            file_name: downloadedFile.name,
            folder_name: matchedFolder.name,
            timestamp: new Date().toISOString()
          }
        };

        setFinalResult({
          status: phoneNumber ? "success" : "error",
          phone_number: phoneNumber,
          message: apiResponsePayload.message
        });
        setApiResult(apiResponsePayload);
        addLog("success", `Proceso completado exitosamente.`);
        setSteps(prev => prev.map((s, idx) => idx === 6 ? { ...s, status: "success", result: apiResponsePayload } : s));
        setIsRunning(false);
      }
    } catch (err: any) {
      addLog("error", `Error: ${err.message}`);
      setSteps(prev => prev.map((s, idx) => idx === nextIndex ? { ...s, status: "error" } : s));
      setIsRunning(false);
    }
  };

  // Copy JSON to clipboard
  const handleCopyJson = () => {
    if (!apiResult) return;
    navigator.clipboard.writeText(JSON.stringify(apiResult, null, 2));
    setCopied(true);
    showNotification("JSON copiado al portapapeles");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans text-[#1E293B]" id="main-container">
      {/* Toast Notification */}
      {notification && (
        <div
          id="toast-notification"
          className={`fixed top-4 right-4 z-50 flex items-center gap-3 px-4 py-3 rounded-lg shadow-xl border text-sm transition-all duration-300 ${
            notification.type === "success"
              ? "bg-emerald-50 border-emerald-200 text-emerald-800"
              : notification.type === "error"
              ? "bg-red-50 border-red-200 text-red-800"
              : "bg-blue-50 border-blue-200 text-blue-800"
          }`}
        >
          {notification.type === "success" && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
          {notification.type === "error" && <AlertCircle className="w-5 h-5 text-red-600" />}
          {notification.type === "info" && <Info className="w-5 h-5 text-blue-600" />}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Header */}
      <header className="h-16 bg-[#002F6C] text-white flex items-center justify-between px-6 shadow-md shrink-0" id="header">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center border border-white/20">
            <Cpu className="w-6 h-6 text-blue-300" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg tracking-wide">ShareFile OCR Automation Assistant</h1>
            <p className="text-xs text-blue-200/80">Procesamiento Inteligente de Escritura Manuscrita</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-full border border-white/15">
            <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse"></span>
            <span className="text-xs font-semibold tracking-wider uppercase">Sistema Activo</span>
          </div>
          <button
            onClick={handleResetDatabase}
            title="Restablecer base de datos simulada"
            className="p-2 hover:bg-white/10 rounded-lg text-white/80 hover:text-white transition-all border border-transparent hover:border-white/10"
            id="reset-db-btn"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Layout Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-0 overflow-hidden" id="workspace">
        
        {/* Left Sidebar - Folder / Files Simulator & Config */}
        <aside className="lg:col-span-3 bg-[#FCFCFD] border-r border-[#E2E8F0] flex flex-col h-full overflow-y-auto" id="sidebar-panel">
          <div className="p-4 border-b border-[#E2E8F0] bg-white">
            <h2 className="text-xs font-bold text-[#64748B] uppercase tracking-wider flex items-center gap-2">
              <Folder className="w-4 h-4 text-[#002F6C]" /> Configuración de Entrada
            </h2>
          </div>

          <div className="p-4 space-y-4">
            {/* Input fields */}
            <div>
              <label className="block text-[11px] font-bold text-[#64748B] uppercase tracking-wider mb-1">
                Carpeta de Búsqueda
              </label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-[#94A3B8]" />
                <input
                  type="text"
                  value={config.folderName}
                  onChange={(e) => setConfig({ ...config, folderName: e.target.value })}
                  placeholder="Ej: Cuentas VIP"
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#E2E8F0] rounded-md text-sm text-[#002F6C] font-semibold focus:outline-none focus:ring-2 focus:ring-[#002F6C] focus:border-transparent transition-all"
                  id="folder-input"
                />
              </div>
              <p className="text-[11px] text-[#64748B] mt-1">Busca coincidencia parcial en ShareFile</p>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-[#64748B] uppercase tracking-wider mb-1">
                Filtro de Nombre (Término)
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 absolute left-3 top-3 text-[#94A3B8]" />
                <input
                  type="text"
                  value={config.fileNameContains}
                  onChange={(e) => setConfig({ ...config, fileNameContains: e.target.value })}
                  placeholder="Ej: VIP"
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#E2E8F0] rounded-md text-sm text-[#002F6C] font-semibold focus:outline-none focus:ring-2 focus:ring-[#002F6C] focus:border-transparent transition-all"
                  id="file-filter-input"
                />
              </div>
              <p className="text-[11px] text-[#64748B] mt-1">Filtra archivos que contengan este texto</p>
            </div>
          </div>

          {/* Virtual ShareFile Storage Simulator */}
          <div className="border-t border-[#E2E8F0] flex-1 flex flex-col min-h-[300px]">
            <div className="p-4 border-b border-[#E2E8F0] bg-white flex items-center justify-between">
              <h3 className="text-xs font-bold text-[#64748B] uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#002F6C]" /> ShareFile Virtual Drive
              </h3>
              <button
                onClick={() => setIsCreatingNewFile(true)}
                className="text-xs flex items-center gap-1 text-[#0056B3] hover:text-[#002F6C] font-semibold transition-all px-2 py-1 rounded bg-[#EFF6FF] hover:bg-[#DBEAFE]"
                id="add-file-btn"
              >
                <Plus className="w-3.5 h-3.5" /> Crear Nota
              </button>
            </div>

            {/* Simulated folders list */}
            <div className="p-3 bg-[#F1F5F9]/60 border-b border-[#E2E8F0]">
              <span className="text-[10px] font-bold text-[#64748B] block mb-2">Carpetas Simuladas:</span>
              <div className="grid grid-cols-2 gap-1">
                {folders.map(f => (
                  <div
                    key={f.id}
                    className={`p-1.5 rounded border text-[11px] font-medium flex items-center gap-1 transition-all truncate ${
                      config.folderName && f.name.toLowerCase().includes(config.folderName.toLowerCase())
                        ? "bg-[#EFF6FF] border-[#BFDBFE] text-[#1E40AF]"
                        : "bg-white border-[#E2E8F0] text-[#475569]"
                    }`}
                  >
                    <Folder className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{f.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* List of files within simulation */}
            <div className="flex-1 p-3 overflow-y-auto space-y-2">
              <span className="text-[10px] font-bold text-[#64748B] block uppercase tracking-wider">Archivos en el Servidor ({files.length}):</span>
              
              {isLoadingFiles ? (
                <div className="py-8 text-center text-[#64748B] text-xs">Cargando archivos...</div>
              ) : files.length === 0 ? (
                <div className="py-8 text-center text-[#64748B] text-xs border border-dashed border-[#E2E8F0] rounded-lg">
                  No hay archivos en ShareFile. Haz clic en "Crear Nota" para añadir uno.
                </div>
              ) : (
                files.map(file => {
                  const isMatch = file.name.toLowerCase().includes(config.fileNameContains.toLowerCase());
                  const folder = folders.find(f => f.id === file.folderId);
                  const isCurrentTarget = selectedFileForOcr?.id === file.id;

                  return (
                    <div
                      key={file.id}
                      className={`p-2.5 rounded-lg border transition-all ${
                        isCurrentTarget
                          ? "bg-amber-50 border-amber-300 shadow-sm"
                          : isMatch
                          ? "bg-[#EFF6FF] border-[#BFDBFE] hover:border-[#93C5FD]"
                          : "bg-white border-[#E2E8F0] hover:border-[#CBD5E1]"
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <FileImage className={`w-4 h-4 mt-0.5 ${isMatch ? "text-blue-500" : "text-gray-400"}`} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-[#1E293B] truncate" title={file.name}>
                            {file.name}
                          </p>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-[10px] text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">
                              📂 {folder ? folder.name : "Raíz"}
                            </span>
                            <span className="text-[9px] text-[#64748B] font-mono">
                              {(file.size / 1024).toFixed(1)} KB
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="p-4 bg-[#EFF6FF] border-t border-[#E2E8F0]">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-[#1E40AF] shrink-0 mt-0.5" />
                <p className="text-[11px] text-[#1E40AF] leading-relaxed">
                  <strong>Entorno Real Gemini:</strong> Si configuras <code>GEMINI_API_KEY</code> en la app, la IA procesará la imagen manuscrita de verdad. Si no, se usará el motor simulado local.
                </p>
              </div>
            </div>
          </div>
        </aside>

        {/* Center Section - Workflow Execution Stepper */}
        <section className="lg:col-span-6 bg-white flex flex-col h-full overflow-hidden" id="workflow-panel">
          
          {/* Action Control Bar */}
          <div className="p-4 bg-white border-b border-[#E2E8F0] flex flex-wrap items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-[#64748B] uppercase tracking-wider">Modo de Ejecución:</span>
              <div className="inline-flex rounded-lg border border-[#E2E8F0] p-0.5 bg-gray-50">
                <button
                  onClick={() => setExecutionSpeed("normal")}
                  className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
                    executionSpeed === "normal"
                      ? "bg-[#002F6C] text-white shadow-sm"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                  id="speed-normal-btn"
                >
                  Estándar
                </button>
                <button
                  onClick={() => setExecutionSpeed("fast")}
                  className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
                    executionSpeed === "fast"
                      ? "bg-[#002F6C] text-white shadow-sm"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                  id="speed-fast-btn"
                >
                  Rápido
                </button>
                <button
                  onClick={() => setExecutionSpeed("step")}
                  className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
                    executionSpeed === "step"
                      ? "bg-[#002F6C] text-white shadow-sm"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                  id="speed-step-btn"
                >
                  Paso a Paso
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isRunning && executionSpeed === "step" && (
                <button
                  onClick={handleNextStepDebug}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg shadow-sm text-sm flex items-center gap-1.5 transition-all animate-bounce"
                  id="next-step-btn"
                >
                  Siguiente Paso <ChevronRight className="w-4 h-4" />
                </button>
              )}

              <button
                onClick={isRunning ? handleResetAssistant : runAssistant}
                className={`px-5 py-2 font-bold rounded-lg shadow-sm text-sm flex items-center gap-1.5 transition-all ${
                  isRunning && executionSpeed !== "step"
                    ? "bg-red-600 hover:bg-red-700 text-white"
                    : "bg-[#002F6C] hover:bg-[#0056B3] text-white"
                }`}
                id="run-assistant-btn"
              >
                {isRunning && executionSpeed !== "step" ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" /> Detener Proceso
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" /> Iniciar Asistente
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Steps list container */}
          <div className="flex-1 overflow-y-auto p-4 bg-[#F8FAFC] space-y-3" id="workflow-steps-container">
            {steps.map((step, idx) => {
              const isCurrent = currentStepIndex === idx && isRunning;
              const isCompleted = step.status === "success";
              const isError = step.status === "error";

              return (
                <div
                  key={step.id}
                  className={`bg-white border rounded-lg p-3.5 transition-all duration-300 shadow-xs flex gap-4 ${
                    isCurrent
                      ? "ring-2 ring-[#002F6C] border-transparent shadow-md transform translate-x-1"
                      : isCompleted
                      ? "border-[#E2E8F0] bg-white opacity-90"
                      : "border-[#E2E8F0] opacity-75"
                  }`}
                >
                  {/* Step Number Badge */}
                  <div className="flex flex-col items-center shrink-0">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                        isCompleted
                          ? "bg-emerald-500 text-white"
                          : isError
                          ? "bg-red-500 text-white animate-pulse"
                          : isCurrent
                          ? "bg-[#002F6C] text-white ring-4 ring-blue-50"
                          : "bg-gray-100 text-[#64748B]"
                      }`}
                    >
                      {isCompleted ? <Check className="w-4 h-4" /> : idx + 1}
                    </div>
                    {idx < steps.length - 1 && (
                      <div className="w-0.5 h-full bg-gray-200 mt-2 rounded"></div>
                    )}
                  </div>

                  {/* Step details content */}
                  <div className="flex-grow space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#1E293B]">{step.label}</span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          isCompleted
                            ? "bg-emerald-100 text-emerald-800"
                            : isError
                            ? "bg-red-100 text-red-800"
                            : isCurrent
                            ? "bg-[#002F6C]/10 text-[#002F6C] animate-pulse"
                            : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        {step.status}
                      </span>
                    </div>

                    <p className="text-xs text-[#64748B] leading-relaxed">{step.description}</p>

                    {/* Step specific results inline rendering */}
                    {isCompleted && step.id === "SEARCH_FOLDERS" && step.result && (
                      <div className="mt-2 text-xs bg-slate-50 p-2 rounded border border-gray-100 font-mono text-slate-700">
                        <Folder className="w-3.5 h-3.5 inline mr-1 text-[#002F6C]" /> Carpeta localizada:{" "}
                        <strong className="text-[#002F6C]">"{(step.result as ShareFileFolder).name}"</strong>
                        <span className="text-[10px] text-gray-400 block mt-0.5">ID: {(step.result as ShareFileFolder).id}</span>
                      </div>
                    )}

                    {isCompleted && step.id === "LIST_ITEMS" && step.result && (
                      <div className="mt-2 text-xs bg-slate-50 p-2 rounded border border-gray-100 font-mono text-slate-700">
                        <span className="text-emerald-600 font-bold">✓ {(step.result as ShareFileFile[]).length} archivos</span> listados con éxito.
                      </div>
                    )}

                    {isCompleted && step.id === "IDENTIFY_FILE" && step.result && (
                      <div className="mt-2 text-xs bg-slate-50 p-2 rounded border border-gray-100 font-mono text-slate-700 flex justify-between items-center">
                        <div>
                          <span>Filtro aplicado: <strong className="text-amber-700">"{(step.result as ShareFileFile).name}"</strong></span>
                        </div>
                        <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">VIP MATCH</span>
                      </div>
                    )}

                    {/* Download result showing the handwritten note */}
                    {isCompleted && step.id === "DOWNLOAD_FILE" && selectedFileForOcr && (
                      <div className="mt-2 space-y-2">
                        <span className="text-[11px] font-bold text-[#64748B] block">Imagen Descargada desde ShareFile:</span>
                        <div className="bg-[#FCFCF9] border border-gray-200 rounded-lg p-3 max-w-sm shadow-sm relative overflow-hidden">
                          <img
                            src={selectedFileForOcr.base64Data}
                            alt="Visual de la nota"
                            className="w-full h-auto max-h-[160px] object-contain rounded"
                          />
                          <div className="absolute top-1 right-1 bg-black/60 text-white text-[9px] px-1.5 py-0.5 rounded font-mono">
                            PREVISTA EN MEMORIA
                          </div>
                        </div>
                      </div>
                    )}

                    {/* OCR Live Text visualizer */}
                    {isCompleted && step.id === "EXTRACT_TEXT" && step.result && (
                      <div className="mt-2 space-y-1">
                        <span className="text-[11px] font-bold text-[#64748B] block">Extracción OCR (Texto Digitalizado):</span>
                        <div className="bg-[#FFFDF5] border border-[#FDE68A] rounded-lg p-3 italic text-xs text-[#475569] leading-relaxed relative font-handwriting">
                          "{step.result}"
                          <Sparkles className="w-4 h-4 text-amber-500 absolute top-2 right-2 animate-pulse" />
                        </div>
                      </div>
                    )}

                    {/* Highlighted extracted phone */}
                    {isCompleted && step.id === "FIND_PHONE" && (
                      <div className="mt-2 text-xs bg-emerald-50 border border-emerald-200 p-2.5 rounded-lg text-emerald-800 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Número extraído:</span>
                          <span className="bg-[#FEF3C7] text-[#92400E] px-2 py-0.5 rounded border border-[#FDE68A] font-bold text-sm select-all">
                            {step.result || "No se encontró"}
                          </span>
                        </div>
                        {step.result && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                            PRECISIÓN: 99%
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Right Sidebar - Output JSON Result */}
        <aside className="lg:col-span-3 bg-[#111827] text-gray-200 flex flex-col h-full overflow-hidden" id="result-panel">
          <div className="p-4 border-b border-gray-800 bg-gray-900 flex items-center justify-between">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-500" /> Resultado JSON (Salida)
            </h2>
            {apiResult && (
              <button
                onClick={handleCopyJson}
                className="text-xs flex items-center gap-1 text-gray-300 hover:text-white hover:bg-gray-800 px-2 py-1 rounded transition-all"
                title="Copiar JSON"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? "Copiado" : "Copiar"}
              </button>
            )}
          </div>

          <div className="flex-1 p-4 font-mono text-xs overflow-y-auto overflow-x-hidden relative" id="json-viewer">
            {apiResult ? (
              <div className="space-y-4">
                <pre className="text-emerald-400 whitespace-pre-wrap select-text leading-relaxed">
                  {JSON.stringify(apiResult, null, 2)}
                </pre>
                
                <div className="border-t border-gray-800 pt-4 space-y-2">
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Metadatos de Ejecución:</span>
                  <div className="grid grid-cols-2 gap-2 text-[10px] text-gray-300 bg-gray-900/60 p-2 rounded border border-gray-800">
                    <div>
                      <span className="text-gray-500 block">Estatus:</span>
                      <span className={`font-semibold ${apiResult.status === "success" ? "text-emerald-400" : "text-red-400"}`}>
                        {apiResult.status?.toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Teléfono:</span>
                      <span className="text-amber-300 font-bold">{apiResult.phone_number || "null"}</span>
                    </div>
                    <div className="col-span-2 mt-1">
                      <span className="text-gray-500 block">Motor OCR:</span>
                      <span className="text-blue-300">{apiResult.metadata?.ocr_engine || "local-sim"}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-gray-500 p-6 space-y-3">
                <Terminal className="w-10 h-10 text-gray-600 animate-pulse" />
                <p className="text-xs">Esperando ejecución de la automatización...</p>
                <p className="text-[10px] leading-relaxed max-w-xs">
                  Configura tus parámetros y presiona <strong className="text-gray-400">"Iniciar Asistente"</strong> para comenzar.
                </p>
              </div>
            )}
          </div>

          {/* Footer of JSON panel */}
          <div className="p-4 bg-gray-950 border-t border-gray-800 text-[10px] text-gray-500 shrink-0">
            <div className="flex items-center justify-between">
              <span>Formato Estándar Assistant</span>
              <span className="font-mono">v1.2.0</span>
            </div>
          </div>
        </aside>
      </div>

      {/* Expandable Debugger Live Logs & Custom Note Canvas Creator */}
      <footer className="bg-white border-t border-[#E2E8F0] shrink-0" id="terminal-footer">
        
        {/* Toggle Bar */}
        <div className="flex items-center justify-between px-6 py-2 border-b border-[#E2E8F0] bg-gray-50 text-xs">
          <div className="flex items-center gap-6">
            <span className="font-bold text-[#002F6C] flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-[#002F6C]" /> Registro de Eventos (Logs en Vivo)
            </span>
            <span className="text-[#64748B]">
              Señales del Servidor: {executionLogs.length} eventos
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[#64748B]">Hora local: 2026-06-26 19:50</span>
          </div>
        </div>

        {/* Dynamic Terminal Box / Flex Container for logs & optional tools */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 h-40" id="terminal-content">
          
          {/* Logs terminal */}
          <div className="lg:col-span-8 bg-gray-950 text-gray-300 p-3 font-mono text-[11px] overflow-y-auto h-full space-y-1">
            {executionLogs.length === 0 ? (
              <div className="text-gray-500 flex items-center gap-2 h-full justify-center">
                <span>Esperando señales de automatización...</span>
              </div>
            ) : (
              executionLogs.map((log, index) => (
                <div key={index} className="flex items-start gap-2 leading-relaxed">
                  <span className="text-gray-500 shrink-0 select-none">[{log.timestamp}]</span>
                  <span
                    className={`font-semibold shrink-0 uppercase text-[10px] px-1 rounded ${
                      log.level === "success"
                        ? "bg-emerald-950 text-emerald-400 border border-emerald-900"
                        : log.level === "error"
                        ? "bg-red-950 text-red-400 border border-red-900 animate-pulse"
                        : log.level === "warning"
                        ? "bg-amber-950 text-amber-400 border border-amber-900"
                        : "bg-gray-800 text-gray-300"
                    }`}
                  >
                    {log.level}
                  </span>
                  <span className="text-gray-200 whitespace-pre-wrap flex-1">{log.message}</span>
                </div>
              ))
            )}
            <div ref={logsEndRef} />
          </div>

          {/* Quick tips & actions info panel */}
          <div className="lg:col-span-4 bg-[#FCFCFD] border-l border-[#E2E8F0] p-4 flex flex-col justify-between h-full overflow-y-auto">
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-[#64748B] uppercase tracking-wider block">
                Instrucciones del Flujo Automatizado
              </span>
              <p className="text-[11px] text-[#475569] leading-normal">
                El asistente simula un cliente empresarial consumiendo las APIs de <strong>ShareFile</strong> mediante OAuth. Escanea la carpeta buscada, filtra, descarga en memoria, y realiza un análisis <strong>OCR Gemini</strong> para devolver el resultado.
              </p>
            </div>
            <div className="text-[10px] text-[#64748B] flex items-center justify-between border-t border-gray-100 pt-2">
              <span>Target Mime: image/png</span>
              <span>OCR Timeout: 12000ms</span>
            </div>
          </div>
        </div>
      </footer>

      {/* New File / Note Creator Modal Overlay */}
      {isCreatingNewFile && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl border border-gray-200 w-full max-w-2xl overflow-hidden flex flex-col">
            
            {/* Modal Header */}
            <div className="bg-[#002F6C] text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-blue-300" />
                <h3 className="font-display font-bold">Crear Nota Manuscrita en ShareFile</h3>
              </div>
              <button
                onClick={() => setIsCreatingNewFile(false)}
                className="text-white/80 hover:text-white hover:bg-white/10 rounded px-2 py-1 text-sm transition-all"
              >
                Cerrar
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 flex-1 space-y-4 overflow-y-auto max-h-[70vh]">
              
              {/* Creator Mode Tabs */}
              <div className="flex bg-gray-100 p-1 rounded-lg">
                <button
                  type="button"
                  onClick={() => setCreationMode("text")}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-all ${
                    creationMode === "text"
                      ? "bg-white text-[#002F6C] shadow-xs"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                >
                  📝 Escribir Nota (Letra manuscrita automática)
                </button>
                <button
                  type="button"
                  onClick={() => setCreationMode("draw")}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-all ${
                    creationMode === "draw"
                      ? "bg-white text-[#002F6C] shadow-xs"
                      : "text-gray-500 hover:text-gray-800"
                  }`}
                >
                  🎨 Dibujar Nota (Pizarra táctil/ratón)
                </button>
              </div>

              {/* Form Input fields */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-[#64748B] uppercase tracking-wider mb-1">
                    Nombre del Archivo
                  </label>
                  <input
                    type="text"
                    value={customFileName}
                    onChange={(e) => setCustomFileName(e.target.value)}
                    placeholder="Ej: VIP_Nota_Urgente.png"
                    className="w-full px-3 py-2 bg-white border border-[#E2E8F0] rounded-md text-xs text-[#002F6C] font-semibold focus:outline-none focus:ring-1 focus:ring-[#002F6C]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-[#64748B] uppercase tracking-wider mb-1">
                    Carpeta Destino
                  </label>
                  <select
                    value={customFolderId}
                    onChange={(e) => setCustomFolderId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E2E8F0] rounded-md text-xs text-[#002F6C] font-semibold focus:outline-none focus:ring-1 focus:ring-[#002F6C]"
                  >
                    {folders.map(f => (
                      <option key={f.id} value={f.id}>
                        {f.name} ({f.id})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Text generation controls */}
              {creationMode === "text" ? (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#64748B] uppercase tracking-wider mb-1">
                      Mensaje / Contenido de la Nota
                    </label>
                    <textarea
                      rows={4}
                      value={customNoteText}
                      onChange={(e) => setCustomNoteText(e.target.value)}
                      placeholder="Escribe el texto de la nota aquí. Ej: Por favor contactar a John Miller VIP..."
                      className="w-full px-3 py-2 bg-white border border-[#E2E8F0] rounded-md text-xs text-[#1E293B] focus:outline-none focus:ring-1 focus:ring-[#002F6C]"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#64748B] uppercase tracking-wider mb-1">
                      Número de Teléfono a Incrustar
                    </label>
                    <input
                      type="text"
                      value={customNotePhone}
                      onChange={(e) => setCustomNotePhone(e.target.value)}
                      placeholder="Ej: (305) 555-0143"
                      className="w-full px-3 py-2 bg-white border border-[#E2E8F0] rounded-md text-xs text-[#1E293B] focus:outline-none focus:ring-1 focus:ring-[#002F6C]"
                    />
                    <span className="text-[10px] text-gray-500">Este teléfono se agregará a la nota en una línea independiente.</span>
                  </div>
                </div>
              ) : (
                /* Drawing Pad Canvas */
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-[#64748B] uppercase tracking-wider">
                      Lienzo de Escritura
                    </span>
                    <button
                      type="button"
                      onClick={clearCanvas}
                      className="text-[10px] text-red-600 hover:text-red-800 font-semibold"
                    >
                      Limpiar Pizarra
                    </button>
                  </div>
                  <div className="border border-[#CBD5E1] rounded-lg overflow-hidden bg-[#FCFCF9] cursor-crosshair">
                    <canvas
                      ref={canvasRef}
                      width={600}
                      height={240}
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                      className="w-full bg-[#FCFCF9]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-[#64748B] uppercase tracking-wider mb-1">
                      Especificar Teléfono para Fallback OCR (Meta)
                    </label>
                    <input
                      type="text"
                      value={customNotePhone}
                      onChange={(e) => setCustomNotePhone(e.target.value)}
                      placeholder="Ej: (305) 555-0143"
                      className="w-full px-3 py-2 bg-white border border-[#E2E8F0] rounded-md text-xs text-[#1E293B] focus:outline-none focus:ring-1 focus:ring-[#002F6C]"
                    />
                    <span className="text-[10px] text-gray-500">Imprescindible para el motor de OCR simulado de la pizarra dibujada a mano.</span>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="bg-gray-50 p-4 border-t border-gray-200 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsCreatingNewFile(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-xs font-semibold hover:bg-gray-100 transition-all text-gray-700"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleUploadCustomFile}
                className="px-5 py-2 bg-[#002F6C] hover:bg-[#0056B3] text-white rounded-lg text-xs font-bold shadow-sm transition-all flex items-center gap-1"
                id="save-file-btn"
              >
                <Upload className="w-3.5 h-3.5" /> Subir a ShareFile
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
