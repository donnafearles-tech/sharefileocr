export interface ShareFileFolder {
  id: string;
  name: string;
  parentId: string | null;
  createdAt: string;
}

export interface ShareFileFile {
  id: string;
  name: string;
  folderId: string;
  mimeType: string;
  size: number; // in bytes
  createdAt: string;
  base64Data: string; // Dynamic or pre-loaded base64 image data
  text?: string; // Hidden ground-truth text for offline/fallback mode
}

export interface ExecutionLog {
  timestamp: string;
  level: "info" | "success" | "warning" | "error";
  message: string;
  payload?: any;
}

export interface AssistantConfig {
  folderName: string;
  fileNameContains: string;
  useRealAI: boolean;
}

export interface AssistantResult {
  status: "success" | "error";
  phone_number: string | null;
  message: string;
}

export type StepId =
  | "SEARCH_FOLDERS"
  | "LIST_ITEMS"
  | "IDENTIFY_FILE"
  | "DOWNLOAD_FILE"
  | "EXTRACT_TEXT"
  | "FIND_PHONE"
  | "RETURN_RESULT";

export interface StepState {
  id: StepId;
  label: string;
  description: string;
  status: "idle" | "running" | "success" | "error";
  result?: any;
}
